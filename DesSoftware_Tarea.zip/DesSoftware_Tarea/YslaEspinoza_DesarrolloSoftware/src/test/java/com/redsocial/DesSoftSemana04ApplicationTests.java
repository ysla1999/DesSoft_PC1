package com.redsocial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesSoftSemana04ApplicationTests {

	@Test
	void contextLoads() {
	}

}

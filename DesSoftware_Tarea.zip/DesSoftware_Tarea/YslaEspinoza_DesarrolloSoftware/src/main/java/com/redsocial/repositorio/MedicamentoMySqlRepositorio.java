package com.redsocial.repositorio;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.redsocial.entidad.Medicamento;

public class MedicamentoMySqlRepositorio implements MedicamentoRepositorio{
    
	@Autowired 
    private JdbcTemplate jdbcTemplate;
	
	@Override
	public int elimina(int idMedicamento) {
		return jdbcTemplate.update("delete from medicamento where idmedicamento=?", new Object[] {idMedicamento});
	}

	@Override
	public int inserta(Medicamento obj) {
		return jdbcTemplate.update("insert into concurso values(null,?,?,?)", new Object[] { obj.getNombre(), obj.getPrecio(), obj.getStock()});
	}

	@Override
	public int actualiza(Medicamento obj) {
		 return jdbcTemplate.update("update medicamento set nombre =?, precio =?, stock =? where idmedicamento =? ", new Object[] { obj.getNombre(), obj.getPrecio(), obj.getStock()});
			}

	@Override
	public List<Medicamento> lista(String filtro) {
		List<Medicamento> lista = jdbcTemplate.query("select * from medicamento where nombre like ? ",new Object[] { filtro+"%" }, new RowMapper<Medicamento>() {
            @Override
            public Medicamento mapRow(ResultSet rs, int arg1) throws SQLException {
            	Medicamento obj = new Medicamento();
            	obj.setIdMedicamento(rs.getInt("idmedicamento"));
            	obj.setNombre(rs.getString("nombre"));
            	obj.setPrecio(rs.getDouble("precio"));
            	obj.setStock(rs.getInt("stock"));
                return obj;
            }
        });
        return lista;
	}
    
}

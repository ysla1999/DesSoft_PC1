package com.redsocial.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redsocial.entidad.Medicamento;
import com.redsocial.repositorio.MedicamentoRepositorio;

@Service
public class MedicamentoServicioImpl implements MedicamentoServicio{

	@Autowired
	private MedicamentoRepositorio repositorio;
	
	@Override
	public int eliminaMedicamento(int idMedicamento) {
		return repositorio.elimina(idMedicamento);
	}

	@Override
	public int insertaMedicamento(Medicamento obj) {
		return repositorio.inserta(obj);
	}

	@Override
	public int actualizaMedicamento(Medicamento obj) {
		return repositorio.actualiza(obj);
	}

	@Override
	public List<Medicamento> listaMedicamento(String filtro) {
		return repositorio.lista(filtro);
	}

}
